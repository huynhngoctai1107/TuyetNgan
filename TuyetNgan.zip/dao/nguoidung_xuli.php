<?php
include("pdo.php");
$nguoidangky=$_POST['ho_ten'];
$matkhau = $_POST['mat_khau'];
$email = $_POST['email'];
$hinh = $_POST['hinh'];
$trangthai = $_POST['trang_thai'];
$vaitro = $_POST['vai_tro'];
 
 
if (isset($_POST['gui'])) {
   
    $sql_themnguoidung = "INSERT INTO khach_hang(ho_ten,mat_khau,email,hinh) VALUES('".$nguoidangky."','".$matkhau."','".$email."','".$hinh."')";
    mysqli_query($mysqli, $sql_themnguoidung);
    header('Location: ../login.php');


} elseif (isset($_POST['sua'])) {
    $sql_update_nguoidung = "UPDATE  khach_hang SET ho_ten='" .$nguoidangky. "' , mat_khau='" .$matkhau. "' , vai_tro='" .$vaitro. "', kich_hoat='" .$trangthai. "' WHERE ma_kh= ' $_GET[makh]' ";
    mysqli_query($mysqli, $sql_update_nguoidung);
    header('Location: ../admin/index.php?action=khach_hang&query=them'); 
} else {
    $id = $_GET['makh'];
    $sql_xoasp = "DELETE FROM  khach_hang WHERE ma_kh ='" . $id . "'  ";
    mysqli_query($mysqli, $sql_xoasp);
    header('Location: ../admin/index.php?action=khach_hang&query=them');
}
?>