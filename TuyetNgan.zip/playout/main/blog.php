<section>
        <div class="container">
            <div class="row" style="display: flex;justify-content: center;">
                
                 
                <div class="col-sm-9">
                    <div class="blog-post-area">
                        <h2 class="title text-center">MỚI NHẤT TỪ ​​BLOG CỦA CHÚNG TÔI</h2>
                        <div class="single-blog-post">
                            <h3>Cơ sở làm bánh mới nhất</h3>
                            <div class="post-meta">
                               
                                <span>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star-half-o"></i>
								</span>
                            </div>
                            <a href="">
                                <img src="./images/cs.jpeg" alt="">
                            </a>
                            <p>Cơ sở sản xuất Hoàng Hằng bắt đầu đi vào hoạt động từ năm 2004, đến năm 2018 cơ sở đã đưa vào vận hành dây chuyền sản xuất hiện đại với vốn đầu tư hơn 2 tỉ đồng. Dây chuyền sản xuất có thể.</p>
                            <a class="btn btn-primary" href="">Đọc Thêm</a>
                        </div>
                        <div class="single-blog-post">
                            <h3>Giấy Chứng nhận an toàn thực phẩm</h3>
                            <div class="post-meta">
                               
                                <span>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star-half-o"></i>
								</span>
                            </div>
                            <a href="">
                                <img src="./images/giay.png" alt="">
                            </a>
                            <p>Co quan chuc nang da phai lam viec cho cac co gai, va se tiep tuc theo duoi su nghiep dien xuat, nhung luc nao cung phai lam viec va cham soc. Vì đến từng chi tiết nhỏ nhất, không ai nên thực hành bất kỳ loại công việc nào trừ khi anh ta thu được một số lợi ích từ nó. Chớ giận hờn đau đớn trách móc trong niềm vui sướng muốn bạc tóc cho khỏi đau đớn với hy vọng không có giống.</p>
                            <a class="btn btn-primary" href="">Đọc Thêm</a>
                        </div>
                         
                        <div class="pagination-area">
                            <ul class="pagination">
                                <li><a href="" class="active">1</a></li>
                                <li><a href="">2</a></li>
                                <li><a href="">3</a></li>
                                <li><a href=""><i class="fa fa-angle-double-right"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
