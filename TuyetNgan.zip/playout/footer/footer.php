<footer id="footer">
        <!--Footer-->
        <div class="footer-top">
            <div class="container">


                <div class="footer-widget">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-2">
                                <div class="single-widget">
                                    <h2>Dịch Vụ</h2>
                                    <ul class="nav nav-pills nav-stacked">
                                        <li><a href="contact-us.php">Liên hệ chúng tôi</a></li>
                                        <li><a href="">Câu hỏi thường gặp</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="single-widget">
                                    <h2>SẢN PHẨM</h2>
                                    <ul class="nav nav-pills nav-stacked">
                                        <li><a href="index.php">Các loại bánh</a></li>
                                        <li><a href="index.php">Bánh ngọt</a></li>
                                        <li><a href="index.php">Bánh kem</a></li>
                                        <li><a href="index.php">Bánh bơ</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="single-widget">
                                    <h2>CHÍNH SÁCH</h2>
                                    <ul class="nav nav-pills nav-stacked">
                                        <li><a href="404.php">Điều khoản sử dụng</a></li>
                                        <li><a href="404.php">Chính sách bảo mật</a></li>
                                        <li><a href="404.php">Chính sách hoàn tiền</a></li>

                                    </ul>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="single-widget">
                                    <h2>GIỚI THIỆU</h2>
                                    <ul class="nav nav-pills nav-stacked">
                                        <li><a href="gioithieu.php">Thông Tin Cửa Hàng</a></li>
                                        <li><a href="contact-us.php">Vị Trí Cửa Hàng</a></li>
                                        <li><a href="404.php">Chương Trình Liên Kết</a></li>
                                      <li><a href="404.php">Bản Quyền</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-sm-3 col-sm-offset-1">
                                <div class="single-widget">
                                    <h2>TUYẾT NGÂN CAKE</h2>
                                    <form action="404.php" class="searchform">
                                        <input type="text" placeholder="Địa Chỉ Email Của Bạn" />
                                        <button type="submit" class="btn btn-default"><i class="fa fa-arrow-circle-o-right"></i></button>
                                        <p>Những bánh ngon được cập nhật mỗi ngày tại cửa chân đến cửa hàng để mua nào. Hoan nghênh các bạn! ...</p>
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="footer-bottom">
                    <div class="container">
                        <div class="row" style="width: 100%; display: flex ; justify-content: space-between;  padding-top: 20px;">
                            <p class="pull-left">Bản Quyền © 2022 TUYẾT NGÂN CAKE Inc. Mọi quyền được bảo lưu..</p>
                            <p class="pull-right">Thiết kế bởi <span><a target="_blank" href="https://www.facebook.com/tai.huynhngoc.58152/">Huỳnh Ngọc Tài</a></span></p>
                        </div>
                    </div>
                </div>

    </footer>